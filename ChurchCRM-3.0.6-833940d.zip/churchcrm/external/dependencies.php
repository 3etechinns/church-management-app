<?php


use ChurchCRM\Service\CalendarService;
use ChurchCRM\Service\FinancialService;
use ChurchCRM\Service\GroupService;
use ChurchCRM\Service\PersonService;
use ChurchCRM\Service\ReportingService;
use ChurchCRM\Service\SystemService;

// DIC configuration
$container['Logger'] = $logger;
