<?php

namespace ChurchCRM\Reports;

class PDF_NewsletterLabels extends PDF_Label
{
    // Constructor
    public function PDF_NewsletterLabels($sLabelFormat)
    {
        parent::__construct($sLabelFormat);
    }
}
